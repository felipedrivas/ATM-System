public interface ATM_Interface {
    void Run();
}
