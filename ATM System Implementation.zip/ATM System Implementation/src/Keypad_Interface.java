public interface Keypad_Interface {
    int getInput();
}
