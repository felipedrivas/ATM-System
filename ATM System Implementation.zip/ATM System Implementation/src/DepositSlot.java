public class DepositSlot implements DepositSlot_Interface{
    @Override
    public boolean isEnvelopeReceived() {
        return true;
    }
}
