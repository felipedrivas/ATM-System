public interface CashDispenser_Interface {
    void dispenseCash(int amount);
    boolean isSufficientCashAvailable(int amount);
}
