public interface DepositSlot_Interface {
    boolean isEnvelopeReceived();
}
