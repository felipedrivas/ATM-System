public class Screen {
    public Screen(){


    }

    public void displayMessage(String a){

        System.out.print(a);
    }

    public void displayMessageLine(String a){
        System.out.println(a);
    }

    public void displayDollarAmount(double a){
        System.out.println("$" + a); //make to two decimal places
    }
}
